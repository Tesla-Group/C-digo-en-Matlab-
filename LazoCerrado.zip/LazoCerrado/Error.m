function [A]=Error(in1,in2,in3)
a=in1;
if abs(in1)>90
    a='La coordenada x est� fuera del rango permitido';
end
A=a;