function [PeriodoX,PeriodoY,PeriodoZ]=Periodo(AnguloX,AnguloY,AnguloZ)
%%control de velocidad%% 
A=max([abs(AnguloX),abs(AnguloY),abs(AnguloZ)]);           %angulo mayor
WN=30;                                      %velocidad angular normal en rpm
PN=(0.005/WN)*60;                           %periodo normal a WN 
% assignin('base','v',Var);
PeriodoX=PN+(abs(AnguloX/A))*PN;                 %periodo para los ejes x y z
PeriodoY=PN+(abs(AnguloY/A))*PN;
PeriodoZ=PN+(abs(AnguloZ/A))*PN;