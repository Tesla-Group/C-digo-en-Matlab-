function [T1, T2, T3] = ScripInversa(x, y, z)
%%
%%C�lculo de �ngulos por CI%%

l1 = 122; 
l2 = 120;
l3 = 20;
T1 = atan2d(y,x);
Dv2 = (x^2 + y^2 + (z - l1)^2 - l2^2 - l3^2)/(2*l2*l3);
T3 = atan2d(+sqrt(1 - Dv2^2),Dv2);
T2 = atan2d(z - l1,sqrt(x^2 + y^2)) - atan2d(l3*sind(T3),l2 + l3*cosd(T3));
%  %%Conversi�n de grados a pasos%%
%  T1 = round(abs((Tx/1.8)));
%  T2 = round(abs(Ty/1.8));
%  T3 = abs(round((Tz/1.8)));
%  global NP
%  NP=T1;

 