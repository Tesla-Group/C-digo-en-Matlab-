function [dirX,dirY,dirZ]=Giro(anguloX,anguloY,anguloZ)
%%cortrol de direcci�n de rotaci�n%%
 if (anguloX < 0)               %dirX, dirY, dirZ sentido de giro de los ejes x y z 
     dirX = 0;
 else
     dirX =1;
 end
 if (anguloY < 0)
     dirY = 0;
 else
     dirY =1;
 end 
 if (anguloZ < 0)
     dirZ = 0;
 else
     dirZ =1;
 end 