function [stepX,stepY,stepZ]=angles2steps(X,Y,Z)
 %%Conversi�n de grados a pasos%%
 stepX = round(abs((X/1.8)));
 stepY = round(abs(Y/1.8));
 stepZ = abs(round((Z/1.8)));